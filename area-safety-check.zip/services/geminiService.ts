
import { GoogleGenAI, type Chat, type GenerateContentResponse, type Content } from "@google/genai";
import { GEMINI_MODEL_NAME, AI_SYSTEM_INSTRUCTION } from '../constants';
import { type GroundingChunk, type GroundingSource } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set. Please ensure it's configured.");
  // In a real app, you might want to throw an error or handle this more gracefully.
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" });

let chatInstance: Chat | null = null;

const getChatInstance = (): Chat => {
  if (!chatInstance) {
    chatInstance = ai.chats.create({
      model: GEMINI_MODEL_NAME,
      config: {
        systemInstruction: AI_SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }], // Enable Google Search grounding
      },
    });
  }
  return chatInstance;
};

export const analyzeAddressSafety = async (
  address: string
): Promise<{ text: string; sources: GroundingSource[] }> => {
  if (!API_KEY) {
    return { text: "Error: API Key is not configured. Please contact support.", sources: [] };
  }
  
  try {
    const chat = getChatInstance();
    // The Content object for the user's message
    const userMessageContent: Content = { parts: [{ text: address }], role: 'user' };
    
    // Pass the Content object within the 'message' property
    const response: GenerateContentResponse = await chat.sendMessage({ message: userMessageContent });
    
    const text = response.text;
    let sources: GroundingSource[] = [];

    if (response.candidates && response.candidates[0]?.groundingMetadata?.groundingChunks) {
      sources = response.candidates[0].groundingMetadata.groundingChunks
        .map((chunk: GroundingChunk) => chunk.web)
        .filter((webSource): webSource is GroundingSource => webSource !== undefined && webSource.uri !== undefined && webSource.uri !== '');
    }
    
    return { text, sources };

  } catch (error) {
    console.error('Error calling Gemini API:', error);
    let errorMessage = 'An unexpected error occurred while analyzing the address.';
    if (error instanceof Error) {
      errorMessage = `Error: ${error.message}`;
    }
    // Check for specific GoogleGenAIError properties if available
    // For example, if (error.httpStatus === 429) { ... }
    return { text: errorMessage, sources: [] };
  }
};
