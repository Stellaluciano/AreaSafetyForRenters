
import React, { useState, useEffect, useCallback } from 'react';
import ChatWindow from './components/ChatWindow';
import ChatInput from './components/ChatInput';
import AddressInputForm from './components/AddressInputForm'; // New component
import { type ChatMessage, MessageSender, type GroundingSource } from './types';
// import { INITIAL_SYSTEM_MESSAGE } from './constants'; // No longer used for initial display
import { analyzeAddressSafety } from './services/geminiService';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]); // Start with an empty array
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [showChat, setShowChat] = useState<boolean>(false); // Controls view

  const handleGoHome = () => {
    setShowChat(false);
    setMessages([]); // Clear chat history
    setError(null);   // Clear any errors
  };

  const handleSendMessage = useCallback(async (text: string) => {
    setError(null);
    const isFirstUserMessageEver = !showChat;

    if (isFirstUserMessageEver) {
      setShowChat(true); // Transition to chat view
    }
    setIsLoading(true);

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      text: text, // This will be the address on the first call
      sender: MessageSender.USER,
      timestamp: new Date(),
    };

    setMessages(prevMessages => 
      isFirstUserMessageEver ? [userMessage] : [...prevMessages, userMessage]
    );

    try {
      const aiResponse = await analyzeAddressSafety(text);
      
      const aiMessage: ChatMessage = {
        id: `ai-${Date.now()}`,
        text: aiResponse.text,
        sender: MessageSender.AI,
        timestamp: new Date(),
        sources: aiResponse.sources,
      };
      setMessages((prevMessages) => [...prevMessages, aiMessage]);

      if (aiResponse.text.startsWith("Error:")) {
        setError(aiResponse.text);
      }

    } catch (e) {
      console.error("Failed to get safety analysis:", e);
      const errorMessageText = e instanceof Error ? e.message : "An unexpected error occurred.";
      setError(errorMessageText);
      const errorMessage: ChatMessage = {
        id: `error-${Date.now()}`,
        text: `Sorry, I couldn't process that request: ${errorMessageText}`,
        sender: MessageSender.SYSTEM, // System message for errors
        timestamp: new Date(),
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [showChat]); // Dependencies for useCallback


  return (
    <div className="flex flex-col h-screen max-w-3xl mx-auto bg-white dark:bg-gray-800 shadow-xl rounded-lg overflow-hidden my-0 md:my-4 border border-gray-200 dark:border-gray-700">
      <header className="relative p-4 border-b border-gray-300 dark:border-gray-700 bg-gradient-to-r from-green-500 to-emerald-600 text-white">
        {showChat && (
          <button
            onClick={handleGoHome}
            className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-white transition-colors"
            aria-label="Back to address input"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18" />
            </svg>
          </button>
        )}
        <h1 className="text-xl md:text-2xl font-bold text-center">AI Renter Safety Assistant</h1>
      </header>
      
      {error && !showChat && ( // Show error prominently if initial address fails
         <div className="p-3 m-4 bg-red-100 border border-red-300 text-red-700 text-sm rounded-md dark:bg-red-900 dark:text-red-200 dark:border-red-700">
           <strong>Error:</strong> {error}
         </div>
      )}
      {error && showChat && ( // Show error within chat view
         <div className="p-3 bg-red-100 border-b border-red-300 text-red-700 text-sm dark:bg-red-900 dark:text-red-200 dark:border-red-700">
           <strong>Error:</strong> {error}
         </div>
      )}

      {!showChat ? (
        <AddressInputForm onAddressSubmit={handleSendMessage} isLoading={isLoading} />
      ) : (
        <>
          <ChatWindow messages={messages} isLoading={isLoading} />
          <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} />
        </>
      )}
       <footer className="p-2 text-center text-xs text-gray-500 dark:text-gray-400 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
        Powered by Gemini API. Safety information is for guidance only.
      </footer>
    </div>
  );
};

export default App;
