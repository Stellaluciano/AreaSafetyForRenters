import React from 'react';

const LoadingIndicator: React.FC = () => {
  return (
    <div className="flex items-center justify-start p-2 ml-2"> {/* Adjusted alignment for chat context */}
      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-green-600"></div>
      <span className="ml-2 text-sm text-gray-600">AI is thinking...</span>
    </div>
  );
};

export default LoadingIndicator;