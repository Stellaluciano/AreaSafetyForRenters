import React, { useState } from 'react';

interface AddressInputFormProps {
  onAddressSubmit: (address: string) => void;
  isLoading: boolean;
}

const AddressInputForm: React.FC<AddressInputFormProps> = ({ onAddressSubmit, isLoading }) => {
  const [address, setAddress] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (address.trim() && !isLoading) {
      onAddressSubmit(address.trim());
      // No need to clear address, as the form will unmount
    }
  };

  return (
    <div className="flex flex-col items-center justify-center flex-grow p-4 md:p-8 bg-gray-50 dark:bg-gray-900">
      <div className="w-full max-w-md p-6 md:p-8 space-y-6 bg-white dark:bg-gray-800 rounded-xl shadow-xl border dark:border-gray-700">
        <h2 className="text-xl md:text-2xl font-semibold text-center text-gray-700 dark:text-gray-200">
          Assess Neighborhood Safety
        </h2>
        <p className="text-sm text-center text-gray-500 dark:text-gray-400">
          Enter a full US address below. Our AI will provide a safety overview tailored for renters.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="address" className="sr-only">
              Address
            </label>
            <input
              id="address"
              name="address"
              type="text"
              autoComplete="street-address"
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 dark:focus:ring-green-400 focus:border-transparent outline-none transition-shadow bg-white dark:bg-gray-700 dark:text-white placeholder-gray-400 dark:placeholder-gray-500"
              placeholder="E.g., 123 Main St, Anytown, USA 12345"
              disabled={isLoading}
              aria-label="Address input for safety check"
              aria-describedby="address-description"
            />
            <p id="address-description" className="sr-only">Enter the full US address you want to check for safety.</p>
          </div>
          <button
            type="submit"
            disabled={isLoading || !address.trim()}
            className="w-full px-6 py-3 bg-green-600 text-white font-medium rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 dark:focus:ring-green-400 focus:ring-opacity-50 disabled:bg-gray-400 dark:disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            aria-live="polite"
          >
            {isLoading ? (
              <>
                <svg
                  className="animate-spin -ml-1 mr-3 h-5 w-5 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                Checking Safety...
              </>
            ) : (
              'Check Safety'
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddressInputForm;