
import React, { useEffect, useRef } from 'react';
// Fix: Import MessageSender from ../types
import { type ChatMessage, MessageSender } from '../types';
import ChatMessageComponent from './ChatMessage';
import LoadingIndicator from './LoadingIndicator';

interface ChatWindowProps {
  messages: ChatMessage[];
  isLoading: boolean;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading }) => {
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  return (
    <div className="flex-grow p-2 md:p-4 space-y-2 overflow-y-auto custom-scrollbar bg-gray-50 dark:bg-gray-900">
      {messages.map((msg) => (
        <ChatMessageComponent key={msg.id} message={msg} />
      ))}
      {isLoading && messages.length > 0 && messages[messages.length-1].sender === MessageSender.USER && <LoadingIndicator />}
      <div ref={chatEndRef} />
    </div>
  );
};

export default ChatWindow;