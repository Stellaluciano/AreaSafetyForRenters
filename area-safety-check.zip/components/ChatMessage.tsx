import React from 'react';
import { type ChatMessage, MessageSender, type GroundingSource } from '../types';

interface ChatMessageProps {
  message: ChatMessage;
}

const SourceDisplay: React.FC<{ sources: GroundingSource[] }> = ({ sources }) => {
  if (!sources || sources.length === 0) {
    return null;
  }
  return (
    <div className="mt-2 pt-2 border-t border-gray-300 dark:border-gray-600">
      <h4 className="text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Sources:</h4>
      <ul className="list-disc list-inside space-y-1">
        {sources.map((source, index) => (
          <li key={index} className="text-xs">
            <a
              href={source.uri}
              target="_blank"
              rel="noopener noreferrer"
              className="text-green-600 hover:text-green-700 hover:underline dark:text-green-400 dark:hover:text-green-500 truncate"
              title={source.title || source.uri}
            >
              {source.title || source.uri}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};


const ChatMessageComponent: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.sender === MessageSender.USER;
  const isSystem = message.sender === MessageSender.SYSTEM;

  const alignment = isUser ? 'justify-end' : 'justify-start';
  const bgColor = isUser 
    ? 'bg-green-600 text-white' 
    : (isSystem ? 'bg-lime-100 text-lime-800 dark:bg-lime-700 dark:text-lime-100' : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200');
  const bubbleStyles = `max-w-xl p-3 rounded-lg shadow ${isUser ? 'ml-auto rounded-br-none' : 'mr-auto rounded-bl-none'}`;
  
  const formattedText = message.text.split('\n').map((line, index, array) => (
    <React.Fragment key={index}>
      {line}
      {index < array.length - 1 && <br />}
    </React.Fragment>
  ));


  return (
    <div className={`flex ${alignment} mb-3 px-2`}>
      <div className={`${bgColor} ${bubbleStyles}`}>
        <div className="text-sm whitespace-pre-wrap">{formattedText}</div>
        {message.sources && message.sources.length > 0 && (
          <SourceDisplay sources={message.sources} />
        )}
        <p className={`text-xs mt-1 ${isUser ? 'text-green-200 dark:text-green-300' : (isSystem ? 'text-lime-600 dark:text-lime-300' : 'text-gray-500 dark:text-gray-400')} text-right`}>
          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
};

export default ChatMessageComponent;